package com.timeexample.services;

import java.time.LocalDateTime;
import java.util.logging.Logger;

public class TimeUtils 
{
	public static LocalDateTime getCurrentTime()
	{
		return LocalDateTime.now();
	} 
}
