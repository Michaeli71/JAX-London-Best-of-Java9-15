package com.timeexample.spi;

import java.time.LocalDateTime;

public interface TimeService
{
	public LocalDateTime getCurrentTime();
}