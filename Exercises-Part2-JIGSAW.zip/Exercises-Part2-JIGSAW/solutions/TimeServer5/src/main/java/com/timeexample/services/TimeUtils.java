package com.timeexample.services;

import java.time.LocalDateTime;
import java.util.logging.Logger;

import com.timeexample.spi.TimeService;

public class TimeUtils implements TimeService
{
	public LocalDateTime getCurrentTime()
	{
		Logger.getGlobal().info("getCurrentTime() is called()");
		return LocalDateTime.now();
	} 
}
