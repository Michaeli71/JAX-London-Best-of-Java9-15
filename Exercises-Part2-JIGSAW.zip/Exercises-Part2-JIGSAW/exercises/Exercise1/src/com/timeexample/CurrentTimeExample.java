package com.timeexample;

import java.time.LocalDateTime;

public class CurrentTimeExample
{
	public static void main(final String[] args)
	{
		System.out.println("Now: " + getCurrentTime());
	}

	public static LocalDateTime getCurrentTime()
	{
		return LocalDateTime.now();
	}   
}
