package exercises.part4_5.java12_13_14;

/**
 * Beispielprogramm für den Workshop "Best of Java 9, 10 und 11" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018/2019 by Michael Inden 
 */
public class Excercise10_Records 
{
	class Square 
	{
		public final double sideLength;
	
		public Square(final double sideLength) 
		{
			this.sideLength = sideLength;
		}
	}
	
	class Circle 
	{
		public final double radius;
	
		public Circle(final double radius) 
		{
			this.radius = radius;
		}
	}
}
